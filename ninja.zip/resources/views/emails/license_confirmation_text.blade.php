{!! $client !!},

{!! trans('texts.payment_message', ['amount' => $amount]) !!}

{!! $license !!}

{!! trans('texts.email_signature') !!}
{!! $account !!}