{!! trans('texts.email_salutation', ['name' => $userName]) !!}

{!! trans("texts.security_code_email_line1") !!}

{!! $code !!}

{!! trans("texts.security_code_email_line2") !!}

{!! trans('texts.email_signature') !!}
{!! trans('texts.email_from') !!}
