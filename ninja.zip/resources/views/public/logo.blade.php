@extends('master')

@section('body')

<center style="padding-top:160px">
<a href="{{ NINJA_WEB_URL }}" target="_blank">
    <img src="{{ asset('images/round_logo.png') }}"/>
</a>
</center>

@stop