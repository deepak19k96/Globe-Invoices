<div class="checkbox">
    <label for="{{ $field }}" class="">
        <input value="1" id="{{ $field }}" type="checkbox" name="{{ $field }}">{{ trans("texts.{$field}") }}
    </label>
</div>
