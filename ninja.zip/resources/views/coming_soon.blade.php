@extends('master')

@section('body')

	<style type="text/css">

		html, body {
		    height: 100%;
		    vertical-align: middle;
		}

		.main_div {
		    width: 500px;
		    height: 200px;
		    
		    position: absolute;
		    top:0;
		    bottom: 0;
		    left: 0;
		    right: 0;

		    font-size: 72px;
		    font-family: arial;
		    color: #CCCCCC;

		    margin: auto;
		}

	</style>

	<div class="main_div">
		coming soon
	</div>

@stop